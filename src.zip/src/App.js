import React from 'react';
import StockpileRochambeau from './components/Main';

function App() {
  return (
    <div className="App">
      <StockpileRochambeau />
    </div>
  );
}

export default App;
